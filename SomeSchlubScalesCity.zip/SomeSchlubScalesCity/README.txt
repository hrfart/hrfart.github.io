
Thanks for downloading Some Schlub Scales Sad City!

In this procedurally generated 2D platformer demo level, you will take control of 
some schlub and scale the buildings of a sad city. It probably won't work on older computers. :( 



IF YOUR COMPUTER TELLS YOU IT'S DAMAGED: 
It's not. 
Go System Preferences --> 
Security and Privacy --> 
General --> 
click the lock --> 
then under "Allow apps downloaded from" select "anywhere" and it should work. 